import { test,expect } from '@playwright/test';

test.describe('Login Tests', () => {
    test.beforeEach('Navigate to DemoPlaze webite', async ({ page }) => {
        await page.goto('https://www.demoblaze.com');
    });

    test('validate that user can register', async ({ page }) => {
        await page.goto('/');
        await page.locator('#signin2').click();
        await page.locator('#sign-username').fill('TesterUser@gmail.com');
        await page.locator('#sign-password').fill('TesterUser@');
        await page.locator('[onclick="register()"]').click();
    
    });

    test('validate that user can login with valid credentials', async ({ page }) => {
        await page.goto('/');
        await page.locator('#login2').click();
        await page.locator('#loginusername').fill('TesterUser@gmail.com'); 
        await page.locator('#loginpassword').fill('TesterUser@'); 
        await page.locator('[onclick="logIn()"]').click();

    });

    test('validate that user can logout', async ({ page }) => {
        await page.goto('/');
        await page.locator('#login2').click();
        await page.locator('#loginusername').fill('TesterUser@gmail.com'); 
        await page.locator('#loginpassword').fill('TesterUser@'); 
        await page.locator('[onclick="logIn()"]').click();
        await page.locator('#logout2').waitFor({ state: 'visible' });
        await page.locator('#logout2').click();
        

    });



    test('User can create an order for an Apple Monitor 24', async ({ page }) => {
    await page.goto('/');
    await page.locator('#login2').click();
    await page.locator('#loginusername').fill('TesterUser@gmail.com'); 
    await page.locator('#loginpassword').fill('TesterUser@'); 
    await page.locator('[onclick="logIn()"]').click();
    await page.locator('a:has-text("Monitors")').click();
    await page.locator('a:has-text("Apple monitor 24")').click();
    await page.locator('.btn-success:has-text("Add to cart")').click();
    page.once('dialog', dialog => dialog.accept()); 
    await page.locator('#cartur').click();
    await expect(page).toHaveURL(/.*cart.html/);
    await page.locator('.btn-success:has-text("Place Order")').click();
    await page.locator('#name').fill('Test User');
    await page.locator('#country').fill('USA');
    await page.locator('#city').fill('New York');
    await page.locator('#card').fill('4111111111111111');
    await page.locator('#month').fill('12');
    await page.locator('#year').fill('2025');
    await page.locator('[onclick="purchaseOrder()"]').click();
    await expect(page.locator('.sweet-alert')).toContainText('Thank you for your purchase!');
    await page.locator('.confirm').click(); 
});

});
