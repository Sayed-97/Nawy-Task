import { test, expect } from '@playwright/test';
import { RegisterPage } from '../pages/registerPage';
import {RegistrationTestData} from '../TestData/registrationData'
test('Scenario 1: User can register with valid data', async ({ page }) => {
  const registerPage = new RegisterPage(page);
  await registerPage.navigate();
  await registerPage.register(RegistrationTestData.email,RegistrationTestData.password);
  
});
