import { test } from '@playwright/test';


test('Scenario 3: User can log out', async ({ page }) => {
        await page.goto('/');
        await page.locator('#login2').click();
        await page.locator('#loginusername').fill('TesterUser@gmail.com'); 
        await page.locator('#loginpassword').fill('TesterUser@'); 
        await page.locator('[onclick="logIn()"]').click();
        await page.locator('#logout2').waitFor({ state: 'visible' });
        await page.locator('#logout2').click();
});

