import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/loginPage';
import { RegisterPage } from '../pages/registerPage';
import { LoginTestData } from '../TestData/loginData';

test('Scenario 2: User can log in with valid email and password', async ({ page }) => {
  const registerPage = new RegisterPage(page);
  const loginPage = new LoginPage(page);
  await registerPage.navigate();
  await registerPage.register(LoginTestData.email, LoginTestData.password);
  await loginPage.login(LoginTestData.email, LoginTestData.password);

 

});

