import { test, expect } from '@playwright/test';
import { CartPage } from '../pages/cartPage';
import { CartTestData } from '../TestData/cartTestData';


test('Scenario 4: Successfully create an order for an Apple monitor 24', async ({ page }) => {
  const cartPage = new CartPage(page);
  await cartPage.navigate();
  const { name, country, city, card,month, year } = CartTestData;
   await cartPage.placeOrder({
    name,
    country,
    city,
    card,
    month,
    year,
  });
  expect(await page.isVisible('text=Thank you for your purchase!')).toBeTruthy();
});
