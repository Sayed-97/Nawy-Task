import {basePage } from './basePage';

export class LoginPage extends basePage {
  constructor(page) {
    super(page);
     /*********Login Locators ******* */
    this.loginButton = '#login2';
    this.usernameInput = '#loginusername';
    this.passwordInput = '#loginpassword';
    this.loginSubmitButton = 'button[onclick="logIn()"]';
    this.item ='#nameofuser'
  }

  
/***********Login Action********* */
  async login(username, password) {
    await this.page.click(this.loginButton);
    await this.page.fill(this.usernameInput, username);
    await this.page.fill(this.passwordInput, password);
    await this.page.click(this.loginSubmitButton);
    await this.page.waitForTimeout(1000);
    await this.page.isVisible(this.item)
  }
}
