import { basePage } from './basePage';

export class HomePage extends basePage {
  constructor(page) {
    super(page);

  /***********Locators******** */

    this.logoutButton = '#logout2';
    this.userWelcome = '#nameofuser';
  }

/*********Actions********* */

  async logout() {
    
    await page.locator('#logout2').waitFor({ state: 'visible' });
    await this.page.click(this.logoutButton);
    
  }

/********Assertion******* */

  async isUserLoggedIn() {
    return await this.page.isVisible(this.userWelcome);
  }
}
