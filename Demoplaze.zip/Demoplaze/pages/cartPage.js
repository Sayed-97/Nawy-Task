import { basePage } from './basePage';

export class CartPage extends basePage {
  constructor(page) {
    super(page);
    /******Locators**********8 */
    this.cartLink = '#cartur';
    this.placeOrderButton = 'button[data-target="#orderModal"]';
    this.nameInput = '#name';
    this.countryInput = '#country';
    this.cityInput = '#city';
    this.cardInput = '#card';
    this.monthInput = '#month';
    this.yearInput = '#year';
    this.purchaseButton = 'button[onclick="purchaseOrder()"]';
    this.monitors='a:has-text("Monitors")'
    this.item='text=Apple monitor 24'
    this.addTocartt='text=Add to cart'

   
    
  }
/**********Action************ */
  async placeOrder(customerDetails) {
    await this.page.click(this.monitors);
    await this.page.click(this.item);
    await this.page.click(this.addTocartt);
    await this.page.click(this.cartLink);
    await this.page.click(this.placeOrderButton);
    await this.page.fill(this.nameInput, customerDetails.name);
    await this.page.fill(this.countryInput, customerDetails.country);
    await this.page.fill(this.cityInput, customerDetails.city);
    await this.page.fill(this.cardInput, customerDetails.card);
    await this.page.fill(this.monthInput, customerDetails.month);
    await this.page.fill(this.yearInput, customerDetails.year);
    await this.page.click(this.purchaseButton);
  }
}
