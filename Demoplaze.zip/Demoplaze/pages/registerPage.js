import {basePage } from './basePage';

export class RegisterPage extends basePage {
  constructor(page) {
    super(page);


    /*********Registration Locators ******* */
    this.signupButton = '#signin2';
    this.usernameInput = '#sign-username';
    this.passwordInput = '#sign-password';
    this.signupSubmitButton = 'button[onclick="register()"]';
  }

/***********Registration Action********* */
  async register(username, password) {
    await this.page.click(this.signupButton);
    await this.page.fill(this.usernameInput, username);
    await this.page.fill(this.passwordInput, password);
    await this.page.click(this.signupSubmitButton);
    await this.page.waitForTimeout(1000); 
  }
}
