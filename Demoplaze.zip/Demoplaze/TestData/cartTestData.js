

 export const CartTestData = {
    name: 'John Doe',
    country: 'USA',
    city: 'New York',
    card: '1234 5678 9123 4567',
    month: '12',
    year: '2025',
  
};