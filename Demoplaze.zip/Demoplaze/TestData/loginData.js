import { faker } from '@faker-js/faker';

 export const LoginTestData = {
  password: faker.internet.password(),
  email: faker.internet.email()
};