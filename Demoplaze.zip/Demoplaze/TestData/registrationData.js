import { faker } from '@faker-js/faker';

  export const RegistrationTestData = {
  password: faker.internet.password(),
  email: faker.internet.email(),

};